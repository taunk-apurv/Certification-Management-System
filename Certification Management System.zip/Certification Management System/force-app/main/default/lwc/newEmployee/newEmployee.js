import { LightningElement, api } from 'lwc';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';

export default class NewEmployee extends LightningElement {
    @api objectApiName = 'Employee__c';
    handlesuccess(event){
        const evt = ShowToastEvent({
            title: "Employee Create",
            message : "Record Id - " + event.detail.Id + "Created",
            variant: "success",
        });
        this.dispatchEvent(evt);
    }
}