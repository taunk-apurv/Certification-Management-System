import { LightningElement,track, wire } from 'lwc';
import { getListUi } from 'lightning/uiListApi';

import VOUCHER_OBJECT from '@salesforce/schema/Voucher__c';
import { NavigationMixin } from 'lightning/navigation';

export default class EmployeeListView extends NavigationMixin(LightningElement) 
{
    @track recordList;
    @track error;
    @wire(getListUi, {objectApiName: VOUCHER_OBJECT,listViewApiName: 'All'})
    listView({error,data}) {
        if (data) {
            this.recordList = data.records.records;
        } else if (error) {
            this.error = error;
        }
    }

    handleView(event)
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.target.value,
                objectApiName: 'Voucher__c',
                actionName: 'view',
            },
        });
    }

    createNewVoucher()
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Voucher__c',
                actionName: 'new'
            }
        });
    }
}