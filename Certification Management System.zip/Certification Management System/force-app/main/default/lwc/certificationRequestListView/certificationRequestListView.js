import { LightningElement, track, wire } from 'lwc';
import CRController from '@salesforce/apex/CertificationRequestController.getCRRecords';
import { NavigationMixin } from 'lightning/navigation';
import { refreshApex } from '@salesforce/apex';

export default class CertificationRequestListView extends NavigationMixin(LightningElement) {
    @track recordList;
    @track error;
    CRRecords;
    @wire(CRController)
    listView(result){
        this.CRRecords = result;
        if(result.data) {
            this.recordList = result.data;
            this.error = undefined;
        } else if (result.error) {
            this.error = result.error;
            this.recordList = undefined;
        }
    }

    handleView(event)
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.target.value,
                objectApiName: 'Certification_Request__c',
                actionName: 'view',
            },
        });
    }

    createNewCertificationRequest()
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Certification_Request__c',
                actionName: 'new'
            }
        });
        
    }
    connectedCallback() {
        // Refresh the data on load
        if (this.CRRecords && this.CRRecords.data) {
            refreshApex(this.CRRecords);
        }
    }
}