import { LightningElement, track, wire } from 'lwc';
import {getListUi} from 'lightning/uiListApi';
import CERTIFICATION_OBJECT from '@salesforce/schema/Certification__c';
import {NavigationMixin} from 'lightning/navigation';


export default class CertificationListView extends NavigationMixin(LightningElement) {
    @track recordList;
    @track error;
    @wire(getListUi, {objectApiName : CERTIFICATION_OBJECT,listViewApiName: 'All'})
    listView({error,data}) {
        if (data) {
            this.recordList = data.records.records;
        } else if (error) {
            this.error = error;
        }
    }

    handleView(event)
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.target.value,
                objectApiName: 'Certification__c',
                actionName: 'view',
            },
        });
    }

    createNewCertification(){
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Certification__c',
                actionName: 'new'
            }
        });
    }
}