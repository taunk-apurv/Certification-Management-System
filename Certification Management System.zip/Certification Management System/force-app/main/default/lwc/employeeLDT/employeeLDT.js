import { LightningElement, track, wire } from 'lwc';
import getEmployeeRecords from '@salesforce/apex/EmployeeController.getEmployeeRecords';

export default class EmployeeLDT extends LightningElement {
    @track data;
    @track columns = [
        {label:'Employee Id', fieldName: 'Emp_Id__c', type: 'Auto Number'},
        {label:'Name', fieldName: 'Name', type: 'Text'},
        {label:'Company Name', fieldName: 'Company_Name__c', type: 'Text'},
    ];
    @wire(getEmployeeRecords)
    employeeRecords({error, data}){
        if(data){
            this.data = data;
            this.error = null;
        }
        else{
            this.error = error;
            this.data = undefined;
        }
    }
}