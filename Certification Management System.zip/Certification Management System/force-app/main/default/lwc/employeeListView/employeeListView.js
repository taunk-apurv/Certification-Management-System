import { LightningElement,track, wire } from 'lwc';
import { getListUi } from 'lightning/uiListApi';

import EMPLOYEE_OBJECT from '@salesforce/schema/Employee__c';
import { NavigationMixin } from 'lightning/navigation';

export default class EmployeeListView extends NavigationMixin(LightningElement) 
{
    @track recordList;
    @track error;
    @wire(getListUi, {objectApiName: EMPLOYEE_OBJECT,listViewApiName: 'All'})
    listView({error,data}) {
        if (data) {
            this.recordList = data.records.records;
        } else if (error) {
            this.error = error;
        }
    }

    handleView(event)
    {
        console.log('View Pressed');
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.target.value,
                objectApiName: 'Employee__c',
                actionName: 'view',
            },
        });
    }

    createNewEmployee()
    {
        console.log('New Pressed');
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Employee__c',
                actionName: 'new'
            }
        });
    }
}