import { LightningElement, api } from 'lwc';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import {NavigationMixin} from 'lightning/navigation';

export default class NewVoucher extends LightningElement {
    @api objectApiName = 'Voucher__c';
    handlesuccess(event){
        const evt = ShowToastEvent({
            title: "Voucher Create",
            message : "Record Id - " + event.detail.Id + "Created",
            variant: "success",
        });
        this.dispatchEvent(evt);
        this[NavigationMixin.Navigate]({
            type: 'standard_recordPage',
            attributes: {
                recordId : event.detail.Id,
                objectApiName : 'Voucher__c',
                actionName : 'view'
            },
        });
    }
}