import { LightningElement,api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import EMPLOYEE_COMPANYNAME from '@salesforce/schema/Employee__c.Company_Name__c';
import EMPLOYEE_EMAIL from '@salesforce/schema/Employee__c.Emp_Email__c';
import EMPLOYEE_EXPERIENCE from '@salesforce/schema/Employee__c.Experience__c';
import EMPLOYEE_PRIMARYSKILL from '@salesforce/schema/Employee__c.Primary_Skill__c';
import EMPLOYEE_SECONDARYSKILL from '@salesforce/schema/Employee__c.Secondary_Skill__c';


export default class EmployeeQuickUpdate extends NavigationMixin(LightningElement) 
{
    fieldList = [EMPLOYEE_COMPANYNAME, EMPLOYEE_EMAIL, EMPLOYEE_EXPERIENCE, EMPLOYEE_PRIMARYSKILL, EMPLOYEE_SECONDARYSKILL];
    @api recordId;
    @api objectApiName;
    navigateToRecordEditPage() 
    {
        // Opens the Employee record modal
        // to view a particular record.
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.recordId,
                actionName: 'edit'
            }
        });
    }
}