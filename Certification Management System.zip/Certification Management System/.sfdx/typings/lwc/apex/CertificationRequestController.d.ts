declare module "@salesforce/apex/CertificationRequestController.getCRRecords" {
  export default function getCRRecords(): Promise<any>;
}
